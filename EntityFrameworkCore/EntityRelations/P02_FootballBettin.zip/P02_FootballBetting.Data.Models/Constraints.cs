﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02_FootballBetting.Data.Models
{
    public class Constraints
    {
        public const int ColorNameLenght = 100;

        public const int UsernameLenght = 50;

        public const int PositionNameLenght = 60;

        public const int InitialsLenght = 3;
    }
}
