﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-GUVMUS8\SQLEXPRESS;Database=Medicine;Integrated Security=True";
    }
}
