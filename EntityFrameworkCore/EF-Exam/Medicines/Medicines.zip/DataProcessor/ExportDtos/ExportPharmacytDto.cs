﻿namespace Medicines.DataProcessor.ExportDtos
{
    public class ExportPharmacytDto
    {
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
    }
}