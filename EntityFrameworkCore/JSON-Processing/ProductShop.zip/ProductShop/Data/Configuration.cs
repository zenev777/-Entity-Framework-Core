﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-GUVMUS8\SQLEXPRESS;Database=ProductShop;Integrated Security=True";
    }
}
